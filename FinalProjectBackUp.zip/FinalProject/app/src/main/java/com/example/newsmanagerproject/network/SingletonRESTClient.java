package com.example.newsmanagerproject.network;

public class SingletonRESTClient {
}
